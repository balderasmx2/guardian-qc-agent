# GUARDIAN QC Agent — How It Works

## Agent: Hermes (NousResearch)
## Model: Qwen3.6-35B-A3B-FP8 via vLLM
## Hardware: Dell GB10 Grace Blackwell

## What the agent does
GUARDIAN is a Hermes AI agent that receives a natural language prompt,
writes and executes Python + bash tool calls to analyze video files,
and generates a structured QC report — with zero human intervention.

## Tool calls the agent makes
1. bash: find [folder] -name "*.mp4" — discovers files
2. bash: ffprobe -v quiet -print_format json -show_streams [file] — reads specs
3. python: compares values against project specs, flags failures
4. python: generates PDF report via fpdf2
5. bash: sha256sum [file] — provenance hash per asset

## Intelligence — what the agent interprets
- Not just "18fps" — "This will cause timing drift in a 24fps timeline"
- Not just "44.1kHz" — "Audio sync issues at delivery, project requires 48kHz"
- Not just "0.166s" — "Below minimum threshold, unusable for broadcast"

## Action — what the agent produces
- qc_report.json — structured data per file
- qc_report.pdf — 49-page actionable report
- Console output — real-time diagnosis during scan

## Run
Start vLLM, start Hermes, enter prompt:
"Scan [folder] for mp4 files. Flag FAIL if not 4K, not 24fps,
audio not 48kHz, or duration under 1 second. Generate PDF report."
